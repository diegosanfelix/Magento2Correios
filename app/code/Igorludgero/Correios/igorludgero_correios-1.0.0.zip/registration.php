<?php
/**
 * Created by PhpStorm.
 * User: igorludgeromiura
 * Date: 04/09/16
 * Time: 14:29
 */
\Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE,
        'Igorludgero_Correios',
        __DIR__
    );