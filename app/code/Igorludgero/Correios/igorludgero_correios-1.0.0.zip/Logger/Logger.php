<?php
/**
 * Created by PhpStorm.
 * User: igorludgeromiura
 * Date: 05/09/16
 * Time: 16:29
 */

namespace Igorludgero\Correios\Logger;

class Logger extends \Monolog\Logger
{
}