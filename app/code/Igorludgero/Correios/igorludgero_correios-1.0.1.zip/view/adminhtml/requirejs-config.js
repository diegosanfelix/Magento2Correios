var config = {
    map: {
        '*': {
            maskedinput: 'Igorludgero_Correios/js/jquery.maskedinput.min'
        }
    }
};